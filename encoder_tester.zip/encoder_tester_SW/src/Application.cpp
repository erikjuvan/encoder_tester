#include "Application.hpp"
#include "Communication.hpp"
#include <fstream>
#include <iostream>
#include <string>

static constexpr int  BUFFER_SIZE{1000};
static Communication* p_communication;

enum class Event {
    AR = 0,
    AF = 1 << 30,
    BR = 1 << 31,
    BF = 1 << 31 | 1 << 30
};

std::string to_string(Event ev)
{
    std::string tmp;

    if (ev == Event::AR) {
        tmp += "ar";
    } else if (ev == Event::AF) {
        tmp += "af";
    } else if (ev == Event::BR) {
        tmp += "br";
    } else if (ev == Event::BF) {
        tmp += "bf";
    }

    return tmp;
}

void RecordValues(std::string const& filename, std::vector<std::pair<Event, uint32_t>> const& values)
{
    std::ofstream f(filename, std::ios::out); // open for writting and append data
    std::string   buf;

    auto buf_correction = [](std::string& buf) { if (buf[buf.size() - 1] == '\n') buf.pop_back(); };

    if (f.is_open()) {
        buf.clear();
        for (auto const& v : values) {
            buf += ::to_string(v.first) + "," + std::to_string(v.second) + "\n";
        }
        buf_correction(buf);

        f << buf; // Write entire content to file

        f.close();
        std::cout << "Data saved to " << filename << std::endl;
    }
}

void Analyze(std::vector<std::pair<Event, uint32_t>> const& values)
{
    const size_t size = values.size();
    int32_t      max = 0, min = 100000000;
    int32_t      idx_max = 0, idx_min = 0;

    std::cout << "Analysis\n------------------\n";

    for (int i = 0; i < size - 1; ++i) {
        if (values[i].first == values[i + 1].first) {
            std::cout << "Error, no signal change at idx " << i << "\n"
                      << ::to_string(values[i].first) << " " << ::to_string(values[i + 1].first) << "\n"
                      << values[i].second << " " << values[i + 1].second << "\n";
        }
        int32_t diff = values[i + 1].second - values[i].second;
        if (diff > max) {
            max     = diff;
            idx_max = i;
        }

        if (diff < min) {
            min     = diff;
            idx_min = i;
        }
    }
    std::cout << "Min: " << min << " at " << idx_min << "\t"
              << "Max: " << max << " at " << idx_max << "\n";
    std::cout << "------------------\n";
}

void ReadData(uint32_t const inbuf[BUFFER_SIZE], size_t size, std::vector<std::pair<Event, uint32_t>>& outbuf)
{
    for (int i = 0; i < size; ++i) {
        uint32_t val  = inbuf[i];
        uint32_t mask = ((1 << 31) | (1 << 30));
        Event    ev   = static_cast<Event>(val & mask);

        outbuf.push_back(std::pair(ev, val & ~mask));
    }
}

void Application::Run() noexcept
{
    uint32_t readbuf[BUFFER_SIZE];
    size_t   count = 0;
    bool     quit  = false;

    std::vector<std::pair<Event, uint32_t>> values;

    // Clear the left over data
    if (p_communication->IsConnected()) {
        p_communication->Purge();
        p_communication->Write("RST");
        p_communication->Read(readbuf, sizeof(readbuf));
    }

    while (!quit && p_communication->IsConnected()) {
        size_t read = p_communication->Read(readbuf, sizeof(readbuf));
        if (read == sizeof(readbuf)) {
            read /= sizeof(readbuf[0]);
            ReadData(readbuf, read, values);
            count += read;
            std::cout << ".";
            if (count >= RecordSize) {
                if (values.size() > RecordSize) { // delete leftover values in vector (if any)
                    values.erase(values.begin() + RecordSize, values.end());
                }
                std::cout << "\n";
                RecordValues("data.txt", values);
                std::cout << "\n";
                Analyze(values);
                quit = true;
            }
        } else {
            std::cerr << "Read incorrect number of bytes, instead of " << sizeof(readbuf) << " read " << read << " bytes\n";
        }
    }

    std::system("pause");

    delete p_communication;
}

void Application::Init(const std::string& file_name)
{
    std::ifstream            in_file(file_name);
    std::string              str;
    std::vector<std::string> tokens;
    bool                     port_found        = false;
    bool                     record_size_found = false;

    if (in_file.is_open()) {
        while (std::getline(in_file, str)) {
            tokens.push_back(str);
        }
        in_file.close();
    }

    for (int i = 0; i < tokens.size(); ++i) {
        switch (i) {
        case 0: // COM port
            try {
                p_communication->Connect(tokens[i]);
                std::cout << "Connected to port " << tokens[i] << "\n";
                port_found = true;
            } catch (...) {
                std::cerr << "Could not connect to port " << tokens[i] << "\n";
                port_found = false;
            }
            break;
        case 1: // number of bytes
            try {
                RecordSize        = std::stoi(tokens[i]);
                record_size_found = true;
            } catch (std::invalid_argument&) {
                std::cout << RecordSize << " samples: Invalid argument!\n";
            } catch (std::out_of_range&) {
                std::cout << RecordSize << " samples: Out of range!\n";
            }

            break;
        }
    }

    if (!port_found) {
        std::string port;
        std::string input;

        while (true) {
            std::cout << "Port number: ";
            input.clear();
            std::cin >> input;

            if (input == "q" || input == "Q") {
                throw std::string("quit");
                break;
            }

            port = "COM" + input;

            try {
                p_communication->Connect(port);
                std::cout << "Connected to port " << port << "\n";
                break;
            } catch (...) {
                std::cerr << "Could not connect to port " << port << "\n";
            }
        }
    }

    if (!record_size_found) {
        std::string input;
        while (true) {
            std::cout << "Record size (samples): ";
            input.clear();
            std::cin >> input;

            if (input == "q" || input == "Q") {
                throw std::string("quit");
                break;
            }

            try {
                uint32_t tmp = std::stoi(input);
                RecordSize   = tmp;
                break;
            } catch (std::invalid_argument&) {
                std::cout << "Invalid argument!\n";
            } catch (std::out_of_range&) {
                std::cout << "Out of range!\n";
            }
        }
    }

    std::cout << "Recording " << RecordSize << " samples ";
}

void Application::Init()
{
    p_communication = new Communication();

    try {
        Init("config.txt");
    } catch (...) {
        throw;
    }
}
