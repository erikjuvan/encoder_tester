#include "Application.hpp"
#include <iostream>

int main(int argc, char* argv[])
{

    try {
        Application::Init();
    } catch (std::string& s) {
        if (s == "quit")
            ;
        return 0;
    } catch (...) {
        std::cout << "Initialization failed!\n";
        return -1;
    }

    Application::Run();

    return 0;
}