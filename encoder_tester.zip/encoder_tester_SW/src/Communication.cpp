#include "Communication.hpp"
#include <iostream>

Communication::Communication() :
    m_serial("", 256000)
{
}

Communication::~Communication()
{
    Disconnect();
}

void Communication::Connect(const std::string& port)
{
    try {
        m_serial.setPort(port);
        m_serial.open();
    } catch (...) {
        throw;
    }

    m_is_connected = true;
}

void Communication::Disconnect()
{
    m_is_connected = false;
    m_serial.close();
}

size_t Communication::GetRxBufferLen()
{
    if (IsConnected())
        return m_serial.available();
    else
        return 0;
}

size_t Communication::Write(const void* data, int size)
{
    if (IsConnected())
        return m_serial.write((uint8_t*)data, size);
    else
        return 0;
}

size_t Communication::Write(const std::string& data)
{
    if (IsConnected())
        return m_serial.write(data);
    else
        return 0;
}

size_t Communication::Read(void* data, int size)
{
    if (IsConnected())
        return m_serial.read((uint8_t*)data, size);
    else
        return 0;
}

std::string Communication::Readline()
{
    if (IsConnected())
        return m_serial.readline();
    else
        return 0;
}

void Communication::Flush()
{
    if (IsConnected())
        m_serial.flush();
}

void Communication::Purge()
{
    if (IsConnected())
        m_serial.purge();
}

void Communication::SetTimeout(int ms)
{
    auto to = serial::Timeout::simpleTimeout(ms);
    m_serial.setTimeout(to);
}
