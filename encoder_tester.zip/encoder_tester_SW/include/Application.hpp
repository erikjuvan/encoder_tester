#pragma once

#include <string>

class Application
{
private:
    static inline int RecordSize{10000};

    static void Init(const std::string& file_name);

public:
    static void Init();
    static void Run() noexcept;
};