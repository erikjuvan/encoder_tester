#include "usbd_cdc_if.h"
#include <string.h>
#include <usbd_cdc.h>
#include <usbd_core.h>
#include <usbd_desc.h>

USBD_HandleTypeDef       USBD_Device;
void                     SysTick_Handler(void);
void                     OTG_FS_IRQHandler(void);
void                     OTG_HS_IRQHandler(void);
extern PCD_HandleTypeDef hpcd;

int         VCP_read(void* pBuffer, int size);
int         VCP_write(const void* pBuffer, int size);
extern char g_VCPInitialized;

#define ENCODER_CLK __GPIOG_CLK_ENABLE
#define ENCODER_PIN_A GPIO_PIN_2
#define ENCODER_PIN_B GPIO_PIN_3
#define ENCODER_PORT GPIOG

#define TIMx TIM2
#define TIMx_CLK_ENALBE __TIM2_CLK_ENABLE
#define TIMx_IRQ_Handler TIM2_IRQHandler

#define BUFFER_SIZE 1000
uint32_t  g_buffer_i               = 0;
uint32_t  g_buffer[2][BUFFER_SIZE] = {0};
uint32_t  g_buffer_alt             = 0;
uint32_t* g_pBuffer                = 0;

int g_writeToPC = 0;

void BufferAdd(uint32_t val)
{
    g_buffer[g_buffer_alt][g_buffer_i] = val;
    g_buffer_i++;
    if (g_buffer_i >= BUFFER_SIZE) {
        g_buffer_i   = 0;
        g_pBuffer    = g_buffer[g_buffer_alt];
        g_buffer_alt = !g_buffer_alt;
        g_writeToPC  = 1;
    }
}

// IRQ
/////////////////////////////////////
void SysTick_Handler(void)
{
    HAL_IncTick();
}

void OTG_FS_IRQHandler(void)
{
    HAL_PCD_IRQHandler(&hpcd);
}

/* Encoding scheme:
A: MSB = 0
B: MSB = 1
rising: MSB-1 = 0
falling: MSB-1 = 1
*/

// Encoder A
void EXTI2_IRQHandler(void)
{
    uint32_t time = TIMx->CNT;
    EXTI->PR      = EXTI_PR_PR2; // Clear pending bit

    if (ENCODER_PORT->IDR & ENCODER_PIN_A) { // rising edge
                                             // nothing to do
    } else {                                 // falling edge
        time |= 1 << 30;
    }
    BufferAdd(time);
}

// Encoder B
void EXTI3_IRQHandler(void)
{
    uint32_t time = TIMx->CNT;
    EXTI->PR      = EXTI_PR_PR3; // Clear pending bit

    time |= 1 << 31;

    if (ENCODER_PORT->IDR & ENCODER_PIN_B) { // rising edge
                                             // nothing to do
    } else {                                 // falling edge
        time |= 1 << 30;
    }
    BufferAdd(time);
}

#ifdef DEBUG_TIM
void TIMx_IRQ_Handler()
{
    TIMx->SR &= ~(TIM_SR_TIF | TIM_SR_UIF);
    GPIOA->BSRR = GPIO_PIN_8;
}
#endif
/////////////////////////////////////

static void SystemClock_Config(void)
{
    RCC_ClkInitTypeDef       RCC_ClkInitStruct;
    RCC_OscInitTypeDef       RCC_OscInitStruct;
    RCC_PeriphCLKInitTypeDef PeriphClkInitStruct;

    /* Enable HSE Oscillator and activate PLL with HSE as source */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
    RCC_OscInitStruct.HSIState       = RCC_HSI_OFF;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM       = 8;
    RCC_OscInitStruct.PLL.PLLN       = 336;
    RCC_OscInitStruct.PLL.PLLP       = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ       = 7;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
        asm("bkpt 255");
    }

    // Activate the OverDrive to reach the 216 Mhz Frequency
    /*if(HAL_PWREx_EnableOverDrive() != HAL_OK) {
		asm("bkpt 255");
	}*/

    /* Select PLLSAI output as USB clock source */
    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_CLK48;
    PeriphClkInitStruct.Clk48ClockSelection  = RCC_CLK48SOURCE_PLL;
    //PeriphClkInitStruct.PLLSAI.PLLSAIN = 384;
    //PeriphClkInitStruct.PLLSAI.PLLSAIQ = 7;
    //PeriphClkInitStruct.PLLSAI.PLLSAIP = RCC_PLLSAIP_DIV8;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK) {
        asm("bkpt 255");
    }

    /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 
	clocks dividers */
    RCC_ClkInitStruct.ClockType      = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK) {
        asm("bkpt 255");
    }

    SystemCoreClockUpdate();
}

void TIM_Configure()
{
    TIMx_CLK_ENALBE();

    TIMx->PSC = (uint32_t)((SystemCoreClock / 2) / 1e6) - 1;
    TIMx->ARR = 0x3FFFFFFF; // because of encoding inside the value uint32_t in MSB and MSB-1, we can only go to 2**30 values.
    TIMx->EGR = TIM_EGR_UG;
    TIMx->CR1 = TIM_CR1_CEN;
}

void TIM_Reset()
{
    TIMx->EGR = TIM_EGR_UG;
}

void GPIO_Configure()
{
    GPIO_InitTypeDef GPIO_InitStructure;

    // Encoder A and B
    ENCODER_CLK();
    GPIO_InitStructure.Pin   = ENCODER_PIN_A | ENCODER_PIN_B;
    GPIO_InitStructure.Mode  = GPIO_MODE_IT_RISING_FALLING;
    GPIO_InitStructure.Pull  = GPIO_PULLDOWN;
    GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_MEDIUM; // GPIO_SPEED_FREQ_HIGH
    HAL_GPIO_Init(ENCODER_PORT, &GPIO_InitStructure);
}

void EXTI_Configure()
{
    EXTI->IMR |= EXTI_IMR_IM2 | EXTI_IMR_IM3;
    EXTI->RTSR |= EXTI_RTSR_TR2 | EXTI_RTSR_TR3;
    EXTI->FTSR |= EXTI_FTSR_TR2 | EXTI_FTSR_TR3;

    HAL_NVIC_SetPriority(EXTI2_IRQn, 2, 0);
    HAL_NVIC_EnableIRQ(EXTI2_IRQn);
    HAL_NVIC_SetPriority(EXTI3_IRQn, 3, 0);
    HAL_NVIC_EnableIRQ(EXTI3_IRQn);
}

static void USB_Init()
{
    USBD_Init(&USBD_Device, &VCP_Desc, 0);

    USBD_RegisterClass(&USBD_Device, &USBD_CDC);
    USBD_CDC_RegisterInterface(&USBD_Device, &USBD_CDC_encoder_tester_fops);
    USBD_Start(&USBD_Device);
}

static void USB_Deinit()
{
    USBD_Stop(&USBD_Device);
    USBD_DeInit(&USBD_Device);
}

static void Init()
{
    HAL_Init();
    SystemClock_Config();
    GPIO_Configure();
    TIM_Configure();
    EXTI_Configure();

    USB_Init();
}

int main()
{
    char rx_buf[10] = {0};

    Init();

    while (1) {

        if (g_VCPInitialized) {
            if (VCP_read(rx_buf, sizeof(rx_buf)) > 0) {
                if (strcmp(rx_buf, "RST") == 0) {
                    TIM_Reset();
                    g_buffer_i   = 0;
                    g_buffer_alt = 0;
                    g_writeToPC  = 0;
                }
                memset(rx_buf, 0, 10);
            }

            if (g_writeToPC) {
                VCP_write(g_pBuffer, BUFFER_SIZE * sizeof(g_buffer[0][0]));
                g_writeToPC = 0;
            }
        }
    }
}
